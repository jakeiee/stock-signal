---
name: mx-selfselect
description: This skill should be used when the user wants to query, add, or remove stocks from their East Money (东方财富) self-selected stock list (自选股). It provides specialized workflows for calling the 妙想 API to manage the user's watchlist using natural language queries.
---

# 妙想自选股管理 Skill (mx_selfselect)

通过自然语言查询或操作东方财富通行证账户下的自选股数据，调用妙想 API 并解析返回的 JSON 结果。

## API Key 准备

1. 检查本地环境变量 `MX_APIKEY` 是否已设置：
   ```bash
   echo $MX_APIKEY
   ```
2. 若未设置，使用用户描述中提供的默认 apikey：`mkt_HeEVfE9lWxYWMJpYsdLfU4-rWvXyKj5xU0mvS0giDOA`
3. apikey 必须放置于 HTTP 请求的 **Header** 中，字段名为 `apikey`。

## 功能与接口说明

详细的接口说明、字段释义和问句示例见 `references/api_docs.md`。

### 功能一：查询自选股列表

**触发词**：用户问"我的自选股"、"查看自选"、"自选股有哪些"等。

**接口**：POST `https://mkapi2.dfcfs.com/finskillshub/api/claw/self-select/get`

**无需请求体**，只需 Header 中携带 apikey：

```bash
curl -X POST 'https://mkapi2.dfcfs.com/finskillshub/api/claw/self-select/get' \
  --header 'Content-Type: application/json' \
  --header "apikey:${MX_APIKEY:-mkt_HeEVfE9lWxYWMJpYsdLfU4-rWvXyKj5xU0mvS0giDOA}"
```

**结果处理**：
- `status/code == 0` 且 `message == "ok"` 为成功。
- 从 `data.allResults.result.dataList` 提取股票列表，按 `references/api_docs.md` 中的字段说明格式化展示。
- 若 `dataList` 为空，提示用户前往东方财富 App 查看自选股。

### 功能二：添加/删除自选股

**触发词**：
- 添加："把 XX 加入自选"、"添加 XX 到自选股"、"关注 XX"。
- 删除："把 XX 从自选删除"、"取消关注 XX"、"移除 XX"。

**接口**：POST `https://mkapi2.dfcfs.com/finskillshub/api/claw/self-select/manage`

**请求体**：将用户的原始自然语言意图放入 `query` 字段：

```bash
curl -X POST 'https://mkapi2.dfcfs.com/finskillshub/api/claw/self-select/manage' \
  --header 'Content-Type: application/json' \
  --header "apikey:${MX_APIKEY:-mkt_HeEVfE9lWxYWMJpYsdLfU4-rWvXyKj5xU0mvS0giDOA}" \
  --data '{"query": "<用户原始语句>"}'
```

**结果处理**：
- `status/code == 0` 且 `message == "ok"` 为操作成功，向用户确认操作已完成。
- 非 0 状态码时，向用户说明操作失败并展示 `message` 字段内容。

## 工作流程

1. **识别意图**：判断用户是"查询"、"添加"还是"删除"自选股。
2. **获取 apikey**：优先使用环境变量 `MX_APIKEY`，否则使用默认值。
3. **构造请求**：
   - 查询 → 调用 `get` 接口，无请求体。
   - 添加/删除 → 调用 `manage` 接口，将用户原始语句作为 `query`。
4. **解析结果**：根据 `references/api_docs.md` 中的字段说明解析 JSON 响应。
5. **格式化输出**：以清晰的 Markdown 表格或列表形式向用户展示结果。

## 注意事项

- **所有请求必须使用 POST 方法**，不得使用 GET。
- apikey 置于 Header，不得放在 URL 参数或请求体中。
- `manage` 接口的 `query` 字段传递用户的自然语言，无需预处理或翻译。
