# 妙想自选股 API 文档

## 接口汇总

| 功能 | 请求方式 | 接口 URL |
|------|----------|----------|
| 查询自选股列表 | POST | `https://mkapi2.dfcfs.com/finskillshub/api/claw/self-select/get` |
| 添加/删除自选股 | POST | `https://mkapi2.dfcfs.com/finskillshub/api/claw/self-select/manage` |

**所有接口均使用 POST 方法，apikey 放置于请求 Header 中。**

---

## 问句示例

| 类型 | 示例 query |
|------|-----------|
| 查询自选股 | 查询我的自选股列表 |
| 添加自选股 | 把贵州茅台添加到我的自选股列表 |
| 添加自选股 | 把东方财富加入自选 |
| 删除自选股 | 把贵州茅台从我的自选股列表删除 |
| 删除自选股 | 取消关注东方财富 |

---

## 一、查询自选股接口 (`/get`)

### 请求示例

```bash
curl -X POST 'https://mkapi2.dfcfs.com/finskillshub/api/claw/self-select/get' \
  --header 'Content-Type: application/json' \
  --header 'apikey:mkt_HeEVfE9lWxYWMJpYsdLfU4-rWvXyKj5xU0mvS0giDOA'
```

### 响应结构

#### 根节点字段

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `status` / `code` | 数字 | 全局状态码，`0` = 成功 |
| `message` | 字符串 | 全局提示，`ok` = 成功 |
| `requestId` | 字符串 | 请求唯一标识（当前通常为空） |
| `data` | 对象 | 核心业务数据 |
| `stack` | 字符串 | 错误堆栈，报错时用于排查 |

#### `data` 对象字段

| 字段名 | 说明 |
|--------|------|
| `allResults` | 完整的结构化数据对象 |
| `title` | 查询标题（如 `"我的自选"`） |

#### `data.allResults.result` 对象

##### 表头列定义 (`columns` 数组)

每个对象描述表格的一列，关键属性：

| 属性 | 说明 |
|------|------|
| `title` | 列名（如"最新价(元)"、"涨跌幅(%)"） |
| `key` / `indexName` | 数据绑定字段键值或指标代码 |
| `dataType` | 数据类型（`String`、`Double`、`Long`） |
| `sortable` | 是否支持排序 |
| `redGreenAble` | 是否支持红绿涨跌变色（涨跌幅为 `true`） |
| `unit` | 数据单位（`元`、`%`、`股`、`倍`） |
| `hide` | 是否默认隐藏该列 |

##### 股票数据列表 (`dataList` 数组)

每条记录代表一只自选股，关键字段：

| 字段 Key | 含义 |
|----------|------|
| `SECURITY_CODE` | 股票代码 |
| `SECURITY_SHORT_NAME` | 股票简称 |
| `MARKET_SHORT_NAME` | 所在市场（SZ：深交所，SH：上交所） |
| `NEWEST_PRICE` | 最新价（元） |
| `CHG` | 涨跌幅（%） |
| `PCHG` | 涨跌额（元） |
| `010000_TURNOVER_RATE...` | 换手率（%） |
| `010000_LIANGBI...` | 量比 |
| `010000_VOLUME...` | 成交量（股） |
| `010000_TRADING_VOLUMES...` | 成交额（元） |
| `010000_PE_D...` | 动态市盈率（倍） |
| `010000_PB...` | 市净率（倍） |
| `010000_TOAL_MARKET_VALUE...` | 总市值（元） |
| `010000_CIRCULATION_MARKET_...` | 流通市值（元） |

### 数据为空时的处理

若 `dataList` 为空数组，向用户提示：  
> "未查询到您的自选股数据，请前往东方财富 App 查看或添加自选股。"

---

## 二、添加/删除自选股接口 (`/manage`)

### 请求示例

```bash
curl -X POST 'https://mkapi2.dfcfs.com/finskillshub/api/claw/self-select/manage' \
  --header 'Content-Type: application/json' \
  --header 'apikey:mkt_HeEVfE9lWxYWMJpYsdLfU4-rWvXyKj5xU0mvS0giDOA' \
  --data '{"query": "把贵州茅台添加到我的自选股列表"}'
```

### 请求体

| 字段 | 类型 | 说明 |
|------|------|------|
| `query` | 字符串 | 用户的自然语言操作意图，直接传递原始语句 |

### 响应结构

#### 根节点字段

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `status` / `code` | 数字 | 全局状态码，`0` = 成功 |
| `message` | 字符串 | 全局提示，`ok` = 成功 |
| `requestId` | 字符串 | 请求唯一标识 |

### 结果处理

- `code == 0`：操作成功，向用户确认（如"已成功将贵州茅台加入您的自选股列表"）。
- `code != 0`：操作失败，展示 `message` 内容并建议用户检查 apikey 或前往东方财富 App 操作。
