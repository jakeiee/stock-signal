# 妙想金融数据 API 文档

## 接口信息

| 属性 | 说明 |
|------|------|
| 请求方式 | **POST**（必须，不可用 GET） |
| 接口 URL | `https://mkapi2.dfcfs.com/finskillshub/api/claw/query` |
| Content-Type | `application/json` |
| 鉴权方式 | apikey 放置于请求 Header，字段名为 `apikey` |

### 请求体

```json
{
  "toolQuery": "<用户自然语言查询意图>"
}
```

### 完整请求示例

```bash
curl -X POST 'https://mkapi2.dfcfs.com/finskillshub/api/claw/query' \
  --header 'Content-Type: application/json' \
  --header 'apikey:mkt_HeEVfE9lWxYWMJpYsdLfU4-rWvXyKj5xU0mvS0giDOA' \
  --data '{"toolQuery": "东方财富最新价"}'
```

---

## 支持的数据类型

### 1. 行情类数据

股票、行业、板块、指数、基金、债券的实时行情、主力资金流向、估值等数据。

| toolQuery 示例 | 说明 |
|---------------|------|
| `东方财富最新价` | 查询股票实时价格 |
| `贵州茅台今日涨跌幅` | 查询涨跌幅 |
| `宁德时代主力资金流向` | 查询资金流向 |
| `创业板指今日行情` | 查询指数行情 |
| `新能源板块今日涨跌` | 查询板块行情 |

### 2. 财务类数据

上市/非上市公司的基本信息、财务指标、高管信息、主营业务、股东结构、融资情况等。

| toolQuery 示例 | 说明 |
|---------------|------|
| `东方财富2023年净利润` | 财务指标 |
| `贵州茅台前十大股东` | 股东结构 |
| `东方财富董事长` | 高管信息 |
| `宁德时代主营业务` | 主营业务 |

### 3. 关系与经营类数据

股票、非上市公司、股东及高管之间的关联关系，以及企业经营相关数据。

---

## 响应结构详解

### 顶层字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `status` / `code` | 数字 | 全局状态码，`0` = 成功 |
| `message` | 字符串 | 全局提示，`ok` = 成功 |
| `data` | 对象 | 核心业务数据 |

---

### 一级核心路径：`data`

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `data.questionId` | 字符串 | 查数请求唯一标识 ID |
| `data.dataTableDTOList` | 数组 | **核心**：标准化证券指标数据列表，每个元素 = 1个证券 + 1个指标的完整数据 |
| `data.rawDataTableDTOList` | 数组 | 原始未加工的证券指标数据（结构同上） |
| `data.condition` | 对象 | 本次查询条件（关键词、时间范围等） |
| `data.entityTagDTOList` | 数组 | 本次查询所有关联证券的去重汇总信息 |

---

### 二级核心路径：`data.dataTableDTOList[]`

数组内每个对象为**独立的指标数据单元**，包含四大部分：

#### 2.1 证券基础信息

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `code` | 字符串 | 证券完整代码（含市场标识，如 `300059.SZ`） |
| `entityName` | 字符串 | 证券全称（如 `东方财富 (300059.SZ)`） |
| `title` | 字符串 | 本指标数据标题（如 `东方财富最新价`） |

#### 2.2 表格数据核心（渲染用）

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `table` | 对象 | **核心**：标准化表格数据。键 = 指标编码，值 = 指标数值数组；`headName` 为时间/维度列值数组 |
| `rawTable` | 对象 | 原始表格数据，结构同 `table`，未做标准化处理 |
| `nameMap` | 对象 | **核心**：列名映射，将指标编码转为中文名（如 `f2` → `最新价`）；`headNameSub` 为时间列列名 |
| `indicatorOrder` | 数组 | 指标列展示顺序，元素为指标编码（如 `["f2"]`） |

**表格重建逻辑示例**：

假设响应如下：
```json
{
  "table": {
    "headName": ["2024-01-15", "2024-01-16"],
    "f2": [18.50, 18.75]
  },
  "nameMap": {
    "headNameSub": "日期",
    "f2": "最新价"
  },
  "indicatorOrder": ["f2"]
}
```

重建后的 Markdown 表格：

| 日期 | 最新价 |
|------|--------|
| 2024-01-15 | 18.50 |
| 2024-01-16 | 18.75 |

#### 2.3 指标元信息

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `dataType` | 字符串 | 数据来源类型（如 `行情数据` / `数据浏览器`） |
| `dataTypeEnum` | 字符串 | 数据类型枚举（`HQ` = 行情，`DATA_BROWSER` = 数据浏览器） |
| `dataTableType` | 字符串 | 表格类型（`NORM_TABLE` = 标准表格） |
| `field` | 对象 | 当前指标的详细元信息 |
| `fieldSet` | 数组 | 指标元信息集合（单指标时为单元素数组） |

#### 2.4 证券标签信息

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `entityTagDTO` | 对象 | 本指标关联证券的主体属性 |
| `entityTagDTOList` | 数组 | 证券主体属性集合（兼容多证券设计） |

---

### 三级核心路径

#### 3.1 指标元信息：`field`

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `field.returnCode` | 字符串 | 指标唯一编码（如 `ZXJ_f2_3/100000000017975`） |
| `field.returnName` | 字符串 | 指标业务中文名（如 `最新价 / 收盘价`） |
| `field.returnSourceCode` | 字符串 | 指标原始来源编码（如 `f2` / `CLOSE`） |
| `field.returnSourceName` | 字符串 | 指标原始来源名称 |
| `field.startDate` | 字符串 | 查询开始时间 |
| `field.endDate` | 字符串 | 查询结束时间 |
| `field.dateGranularity` | 字符串 | 数据粒度（`DAY` = 日度，`MIN` = 分钟） |
| `field.classCode` | 字符串 | 指标分类编码 |

#### 3.2 证券主体属性：`entityTagDTO`

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `entityTagDTO.secuCode` | 字符串 | 证券纯代码（如 `300059`） |
| `entityTagDTO.marketChar` | 字符串 | 市场标识（`.SZ` = 深交所，`.SH` = 上交所） |
| `entityTagDTO.entityTypeName` | 字符串 | 证券类型（如 `A股` / `港股` / `债券`） |
| `entityTagDTO.fullName` | 字符串 | 证券完整中文名（如 `东方财富`） |
| `entityTagDTO.entityId` | 字符串 | 证券系统内唯一主体 ID |
| `entityTagDTO.className` | 字符串 | 证券大类（如 `沪深京股票` / `创业板股票`） |

---

### 四级路径

#### 4.1 查询条件：`data.condition`

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `condition.search_data_task_0` | 数组 | 原始查询条件，按【证券名 + 指标名 + 时间范围】结构排列 |

#### 4.2 证券主体汇总：`data.entityTagDTOList`

结构与 `dataTableDTOList[].entityTagDTO` 完全一致，为本次查询所有关联证券的去重汇总，可用于页面顶部或筛选栏展示。

---

## 数据为空处理

若 `data.dataTableDTOList` 为空数组，向用户提示：
> "未查询到相关金融数据，建议前往[东方财富妙想AI](https://miaoxiang.eastmoney.com)进一步查询。"
