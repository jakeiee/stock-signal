#!/usr/bin/env python3
"""
妙想资讯搜索脚本 (mx_search)

用法:
    python3 mx_search.py <query> [--save <output_file>] [--top <n>]

环境变量:
    MX_APIKEY  妙想 API Key（必须）

示例:
    python3 mx_search.py "贵州茅台最新研报"
    python3 mx_search.py "美联储加息对A股影响" --top 5
    python3 mx_search.py "商业航天板块近期新闻" --save result.md
"""

import argparse
import json
import os
import sys
from datetime import datetime

import requests

API_URL = "https://mkapi2.dfcfs.com/finskillshub/api/claw/news-search"


def get_apikey() -> str:
    key = os.environ.get("MX_APIKEY", "").strip()
    if not key:
        print(
            "❌ 未找到 MX_APIKEY 环境变量。\n"
            "   请先在妙想 Skills 页面获取 API Key，然后执行：\n"
            "   export MX_APIKEY=your_key_here",
            file=sys.stderr,
        )
        sys.exit(1)
    return key


def search(query: str, apikey: str) -> list[dict]:
    """调用妙想资讯搜索接口，返回结果列表。"""
    headers = {
        "Content-Type": "application/json",
        "apikey": apikey,
    }
    payload = {"query": query}
    try:
        resp = requests.post(API_URL, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
    except requests.RequestException as e:
        print(f"❌ 请求失败: {e}", file=sys.stderr)
        sys.exit(1)

    data = resp.json()
    # 兼容不同响应结构
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("data", "result", "results", "items", "list"):
            if isinstance(data.get(key), list):
                return data[key]
    return [data] if data else []


def format_item(item: dict, idx: int) -> str:
    """将单条资讯格式化为可读文本块。"""
    title = item.get("title", "(无标题)")
    trunk = item.get("trunk", "")
    secu_list = item.get("secuList", [])

    lines = [f"### [{idx}] {title}"]

    if secu_list:
        secu_strs = [
            f"{s.get('secuName', '')}（{s.get('secuCode', '')}，{s.get('secuType', '')}）"
            for s in secu_list
            if s.get("secuName") or s.get("secuCode")
        ]
        if secu_strs:
            lines.append(f"**关联证券**：{' / '.join(secu_strs)}")

    if trunk:
        lines.append("")
        lines.append(str(trunk))

    return "\n".join(lines)


def build_markdown(query: str, items: list[dict], top: int) -> str:
    """将搜索结果构建为 Markdown 文档。"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    total = len(items)
    shown = items[:top]

    header = (
        f"# 妙想资讯搜索结果\n\n"
        f"- **搜索问句**：{query}\n"
        f"- **生成时间**：{now}\n"
        f"- **返回条数**：共 {total} 条，展示前 {len(shown)} 条\n\n"
        f"---\n"
    )
    body = "\n\n---\n\n".join(format_item(item, i + 1) for i, item in enumerate(shown))
    return header + "\n" + body


def main():
    parser = argparse.ArgumentParser(description="妙想资讯搜索")
    parser.add_argument("query", help="搜索问句，如"贵州茅台最新研报"")
    parser.add_argument("--top", type=int, default=10, help="展示前 N 条结果（默认 10）")
    parser.add_argument("--save", metavar="FILE", help="将结果保存为 Markdown 文件")
    parser.add_argument("--json", action="store_true", dest="output_json",
                        help="以 JSON 格式输出原始数据")
    args = parser.parse_args()

    apikey = get_apikey()
    print(f"🔍 搜索中：{args.query} ...", file=sys.stderr)
    items = search(args.query, apikey)

    if not items:
        print("⚠ 未返回任何结果。", file=sys.stderr)
        sys.exit(0)

    print(f"✓ 获取到 {len(items)} 条资讯。", file=sys.stderr)

    if args.output_json:
        print(json.dumps(items[:args.top], ensure_ascii=False, indent=2))
        return

    md = build_markdown(args.query, items, args.top)

    if args.save:
        with open(args.save, "w", encoding="utf-8") as f:
            f.write(md)
        print(f"✓ 已保存到 {args.save}", file=sys.stderr)
    else:
        print(md)


if __name__ == "__main__":
    main()
