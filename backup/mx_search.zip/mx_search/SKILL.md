---
name: mx-search
description: "本 Skill 基于东方财富妙想搜索能力，用于获取时效性金融资讯，包括新闻、研报、公告、政策解读等。避免 AI 参考非权威或过时信息。This skill should be used when the user asks about financial news, research reports, stock announcements, market events, or any time-sensitive financial information requiring authoritative A-share sources."
---

# 妙想资讯搜索 Skill (mx_search)

根据用户问句搜索相关金融资讯，获取与问句相关的资讯信息（如研报、新闻、解读等），并返回可读的文本内容，可选保存到工作目录。

## 触发场景

在以下场景触发本 Skill：

- 用户询问个股最新动态、研报、机构观点
- 用户询问板块/主题的近期新闻或政策
- 用户需要宏观经济事件（美联储、汇率、大盘异动）对 A 股的影响分析
- 用户询问特定公告、交易规则或监管政策
- 任何需要实时、权威金融信源的问题（而非依赖模型训练数据回答）

## 环境准备

使用前检查 `MX_APIKEY` 环境变量是否已配置：

```bash
echo $MX_APIKEY
```

若为空，提示用户到妙想 Skills 页面获取 API Key，并执行：

```bash
export MX_APIKEY=your_key_here
```

详细 API 规格参见 `references/api_reference.md`。

## 执行搜索

使用 `scripts/mx_search.py` 脚本执行搜索：

```bash
# 基础搜索（输出到终端）
python3 scripts/mx_search.py "<用户问句>"

# 限制条数
python3 scripts/mx_search.py "<用户问句>" --top 5

# 保存为 Markdown 文件
python3 scripts/mx_search.py "<用户问句>" --save result.md

# 获取原始 JSON（供进一步解析）
python3 scripts/mx_search.py "<用户问句>" --json
```

脚本路径基于 skill 目录；若从项目目录调用，使用绝对路径：
`~/.codebuddy/skills/mx_search/scripts/mx_search.py`

## 问句构造原则

- 将用户的原始问题直接作为 `query` 传入，妙想会自行进行金融语义理解和信源筛选
- 问句应尽量完整，包含时间范围（如"近期"、"最新"）或具体主体（如股票名称/代码）
- 避免过度精简问句，保留上下文有助于提升召回质量

## 结果处理

搜索结果的核心字段：

| 字段 | 用途 |
|------|------|
| `title` | 资讯标题，用于快速浏览 |
| `trunk` | 正文内容，用于详细分析 |
| `secuList` | 关联证券，用于提取代码/名称 |

根据用户需求对结果进行整理：
- **摘要回答**：提炼各条 `trunk` 中的核心观点，综合成结论
- **列表呈现**：按 `title` 列出资讯列表并附简短说明
- **保存文件**：使用 `--save` 参数将结果写入工作目录供后续使用
