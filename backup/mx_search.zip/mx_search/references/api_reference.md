# 妙想资讯搜索 API 参考

## 接口信息

| 项目 | 值 |
|------|----|
| 请求方式 | POST（必须） |
| 接口地址 | `https://mkapi2.dfcfs.com/finskillshub/api/claw/news-search` |
| Content-Type | `application/json` |
| 鉴权方式 | Header `apikey: <your_key>` |

## 请求体

```json
{ "query": "贵州茅台最新研报" }
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `query` | string | 自然语言问句，支持个股/板块/宏观/事件等金融场景 |

## 响应字段说明

| 字段路径 | 类型 | 说明 |
|---------|------|------|
| `title` | string | 资讯标题，高度概括核心内容 |
| `secuList` | array | 关联证券列表 |
| `secuList[].secuCode` | string | 证券代码，如 `002475` |
| `secuList[].secuName` | string | 证券名称，如 `立讯精密` |
| `secuList[].secuType` | string | 证券类型，如 `股票` / `债券` |
| `trunk` | string/object | 核心正文或结构化数据块，承载具体业务数据 |

## 问句示例

| 类型 | 示例问句 |
|------|---------|
| 个股资讯 | 格力电器最新研报、贵州茅台机构观点 |
| 板块/主题 | 商业航天板块近期新闻、新能源政策解读 |
| 宏观/风险 | A股具备自然对冲优势的公司 汇率风险、美联储加息对A股影响 |
| 综合解读 | 今日大盘异动原因、北向资金流向解读 |

## API Key 获取

在 [妙想 Skills 页面](https://miaoxiang.dfcfs.com) 申请并获取 API Key，然后配置到环境变量：

```bash
export MX_APIKEY=your_key_here
```

建议写入 `~/.zshrc` 或 `~/.bashrc` 以持久化。

## curl 示例

```bash
curl -X POST \
  'https://mkapi2.dfcfs.com/finskillshub/api/claw/news-search' \
  --header 'Content-Type: application/json' \
  --header 'apikey: YOUR_API_KEY' \
  --data '{"query":"立讯精密的资讯"}'
```
